package oddeye;/*
 **description:
 **param&method:
 **caller:
 **problems:
 */

public class Person {
    public void study(){
        System.out.println("good good study,day day up");
    }
}
