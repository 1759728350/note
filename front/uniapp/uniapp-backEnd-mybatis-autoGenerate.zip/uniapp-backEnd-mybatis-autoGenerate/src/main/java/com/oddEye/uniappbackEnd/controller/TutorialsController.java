package com.oddEye.uniappbackEnd.controller;/*
 **description:
 **param&method:
 **caller:
 **problems:
 */


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TutorialsController {

//    @Autowired
//    private TutorialsMapper tutorialsMapper;
//    @PostMapping("/g")
//    public void insertInfo(){
//
//        Tutorials tutorials = new Tutorials();
////        tutorials.setId(112323L);
////        tutorials.setDescription("try");
////        tutorials.setTitle("try");
////        tutorials.setPublished(true);
////        tutorialsMapper.insert(tutorials);
//        System.out.println(tutorialsMapper.selectById(1));
//
//    }


}
