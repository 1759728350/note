package com.oddEye.uniappbackEnd.mapper;

import com.oddEye.uniappbackEnd.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author oddEye
 * @since 2022-04-09
 */
public interface UserMapper extends BaseMapper<User> {

}
