package com.oddEye.uniappbackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniappBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
